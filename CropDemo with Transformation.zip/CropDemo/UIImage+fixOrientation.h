//
//  UIImage+fixOrientation.h
//  instaoverlay
//
//  Created by Maximilian Mackh on 11/11/12.
//  Copyright (c) 2012 mackh ag. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (fixOrientation)

- (UIImage *)fixOrientation;

@end